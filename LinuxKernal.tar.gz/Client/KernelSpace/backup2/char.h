/*
 * char.h -- definitions for the char module
 *
 * Copyright (C) 2010 Benny Cohen 
 * Copyright (C)  Real Time Group
 *
 * The source code in this file can be freely used, adapted,
 * and redistributed in source or binary form, so long as an
 * acknowledgment appears in derived source files.  
 * No warranty is attached;  
 * we cannot take responsibility for errors or fitness for use.
 */

#ifndef _CHAR_H_
#define _CHAR_H_

#include <linux/ioctl.h> /* needed for the _IOW etc stuff used later */

#ifndef MAJOR_NUMBER
#define MAJOR_NUMBER 0   /* dynamic major by default */
#endif


#define ALLOCATED_SPACE_SIZE  512 /* used as kernel buffer*/
int char_open(struct inode *inode, struct file *filp);
int char_release(struct inode *inode, struct file *filp);
static ssize_t char_read(struct file *filp, char __user *buf, size_t count, loff_t *f_pos);
ssize_t char_write(struct file *filp, const char __user *buf, size_t count, loff_t *f_pos);
loff_t  char_llseek(struct file *filp, loff_t off, int whence);

#endif /* _CHAR_H_ */
