/*
 * char.c -- Basic char  Driver module
 *
 * Copyright (C) 2010 Benny Cohen 
 * Copyright (C)  Real Time Group
 *
 * The source code in this file can be freely used, adapted,
 * and redistributed in source or binary form, so long as an
 * acknowledgment appears in derived source files. 
 * No warranty is attached;
 * we cannot take responsibility for errors or fitness for use.
 *
 */


#include <linux/module.h>
//#include <linux/moduleparam.h>
//#include <linux/init.h>

#include <linux/kernel.h>	/* printk() */
#include <linux/slab.h>		/* kmalloc() */
#include <linux/fs.h>		/* everything... */
#include <linux/errno.h>	/* error codes */
#include <linux/types.h>	/* size_t */
#include <linux/fcntl.h>	/* O_ACCMODE */
#include <linux/cdev.h>
#include <linux/uaccess.h>	/* copy_*_user */

#include <linux/device.h>
#include <linux/kdev_t.h>

#include <linux/random.h> /* get_random_bytes */

#include "char.h"		/* local definitions */

/*
 * Globals 
 */
//parameters which can be set at load time.
int major_num =   MAJOR_NUMBER;
int minor_num =   0;

//char *kernel_buff = NULL;
static char kernel_buff[512];
static size_t msg_len = 0;
int gCount = ALLOCATED_SPACE_SIZE;	/* allocated space size is 512 bytes */

MODULE_AUTHOR("Yaron Shemesh");
MODULE_LICENSE("GPL");


//struct char_dev *char_device;	/* allocated in init_module */
//struct cdev cdev;	  /* Char device structure		*/
static dev_t first; // Global variable for the first device number 
static struct cdev c_dev; // Global variable for the character device structure
static struct class *cl; // Global variable for the device class

/************************************************************************************************************************/
/*
 * Open and close
 */
/************************************************************************************************************************/
int char_open(struct inode *inode, struct file *filp)
{
	printk(KERN_NOTICE "char_open() open function was called\n");	
	
	// allocate the global Memory buffer
	/*kernel_buff = kmalloc(gCount, GFP_USER);
	if (kernel_buff==NULL)
	{
		printk(KERN_ERR "char_read() error in Mem Allocation\n");
		return -1;
	}*/
	return 0;          /* success */
}
/************************************************************************************************************************/
int char_release(struct inode *inode, struct file *filp)
{
	printk(KERN_NOTICE "char_release() release function was called\n");
	
	//release the allocated buffer
	/*if(kernel_buff!=NULL)
	{
		kfree(kernel_buff);
		kernel_buff = NULL;
	}*/

	return 0;
}
/************************************************************************************************************************/
/*
 * Data management: read and write
 */
/*ssize_t char_read(struct file *filp, char __user *buf, size_t count,
                  loff_t *f_pos)
{
	printk(KERN_NOTICE "char_read() read function was called\n");
		
	//copy from kernel buffer to user_buffer
	if (copy_to_user(buf, kernel_buff, count))
    {
		count = -EFAULT;
	}
	return count;
}*/

static ssize_t char_read(struct file *f, char __user *buf, size_t len, loff_t *off)
{
	printk(KERN_INFO "Driver: read()\n");
	//copy from kernel buffer to user_buffer
	
	if (copy_to_user(buf, kernel_buff, msg_len))
    {
		len = -EFAULT;
	}
	return len;
	//return 0;
}

typedef struct _MSG_HEADER {
	uint32_t dest_device_addr;
	uint32_t src_device_addr;
	uint16_t gas_pressure;
	uint8_t valves_status;
	uint16_t pipe_temp;
	uint8_t cmd_length;
} __attribute__((packed)) MSG_HEADER;

/************************************************************************************************************************/
ssize_t char_write(struct file *filp, const char __user *buf, size_t count,
                loff_t *f_pos)
{
	MSG_HEADER header;
	int valve1_status = 0; // TODO: read from GPIO15
	int valve2_status = 0; // TODO: read from GPIO16
	int valve3_status = 0; // TODO: read from GPIO17
	uint16_t crc = 0x1234; // TODO: calcualte CRC
	
	printk(KERN_NOTICE "char_write() write function was called\n");
	
	
	if (copy_from_user(kernel_buff + sizeof(header), buf, count))
	{
		count = -EFAULT;
	}
	
	// 1. send message header in UART
	
	header.dest_device_addr = 123;
	header.src_device_addr	= 456;
	get_random_bytes(&header.gas_pressure, 2); // random 16-bit number
	
	
	header.valves_status = (valve1_status&1) | ((valve2_status&1) << 1) | ((valve3_status&1) << 2);
	
	get_random_bytes(&header.pipe_temp, 2); // random 16-bit number (extra: read from ADC)
	header.cmd_length = count;
	printk(KERN_NOTICE "char_write() header.pipe_temp: %x\n", header.pipe_temp);
	printk(KERN_NOTICE "char_write() header.cmd_length: %x\n", header.cmd_length);
	printk(KERN_NOTICE "char_write() count: %x\n", count);
	
	
	memcpy(kernel_buff, &header, sizeof(header));
	
	
	memcpy(kernel_buff + sizeof(header) + count, &crc, sizeof(crc));
	msg_len = sizeof(header) + count + sizeof(crc);
	
	// 1.2 write
	//int ftty = filp_open("\dev\ttyO1", O_RDWR|O_NOCTTY|O_NONBLOCK, 0);
	//printk(KERN_NOTICE "ftty=%d\n", ftty);
	
	// 2. send user data in UART
	
	// 3. send CRC on UART
	
	
	return count;
}
/************************************************************************************************************************/
/************************************************************************************************************************/
struct file_operations char_fops = {
	.owner =    THIS_MODULE,
	.read =     char_read,
	.write =    char_write,
	.open =     char_open,
	.release =  char_release,
};
/************************************************************************************************************************/
/************************************** drv_cleanup_module() ************************************************************/
/* Driver exit point
 * is run when driver is unloaded
 * The cleanup function is used to handle initialization failures as well.
 * Thefore, it must be careful to work correctly even if some of the items
 * have not been initialized
 */
void drv_cleanup_module(void)
{
	cdev_del(&c_dev);
	device_destroy(cl, first);
	class_destroy(cl);
	unregister_chrdev_region(first, 1);
	
	//dev_t devno = MKDEV(major_num, minor_num);

	/* Get rid of our char dev entries */
	//cdev_del(&c_dev);
	
	/* cleanup_module is never called if registering failed */
	//unregister_chrdev_region(devno, 1);
	printk(KERN_NOTICE "char device unregistered");
	printk(KERN_NOTICE "char device module unloaded");
}
/************************************** init_module() *******************************************************************/
/* main entry point for the driver,
 * first to be run when driver is uploaded
 */ 
int drv_init_module(void)
{
	int result;
	dev_t dev = 0;
	major_num = 0;

/*
 * Get a range of minor numbers to work with, asking for a dynamic
 * major unless directed otherwise at load time.
 */
	if (major_num) 
	{
		printk(KERN_WARNING "init_module():  major =  %d\n", major_num);
		dev = MKDEV(major_num, minor_num);
		result = register_chrdev_region(dev, 1, "iot-device");
	} 
	else 
	{
		printk(KERN_WARNING "init_module():  major =  %d\n dont have a major so ask the o.s. for one\n", major_num);
		result = alloc_chrdev_region(&first, minor_num, 1,"iot-device");
		major_num = MAJOR(dev);
		printk(KERN_WARNING "init_module():  the o.s. gave us major =  %d\n", major_num);
	}
	
	if ((cl = class_create(THIS_MODULE, "iot-class")) == NULL)
	{
		unregister_chrdev_region(first, 1);
		return -1;
	}
	
	if (result < 0) 
	{
		printk(KERN_WARNING "init_module(): REGISTRATION FAILURE %d\n", major_num);
		goto fail;  // Make this more graceful 
	}

	
    /* Initialize the char device. */
	//setup_cdev();
	if (device_create(cl, NULL, first, NULL, "iot-device") == NULL)
	{
		class_destroy(cl);
		unregister_chrdev_region(first, 1);
		return -1;
	}
	
	cdev_init(&c_dev, &char_fops);
	if (cdev_add(&c_dev, first, 1) == -1)
	{
		device_destroy(cl, first);
		class_destroy(cl);
		unregister_chrdev_region(first, 1);
		return -1;
	}
	
	return 0; /* succeed */

  fail:
	drv_cleanup_module();
	return result;
}
/************************************************************************************************************************/
module_init(drv_init_module);
module_exit(drv_cleanup_module);

