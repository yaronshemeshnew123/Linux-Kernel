/*
 * user.c -- Basic char user-space app
 *
 * Copyright (C) 2010 Benny Cohen 
 * Copyright (C)  Real Time Group
 *
 * The source code in this file can be freely used, adapted,
 * and redistributed in source or binary form, so long as an
 * acknowledgment appears in derived source files. 
 * No warranty is attached;
 * we cannot take responsibility for errors or fitness for use.
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <assert.h>

//Defines
#define COUNT 20

//prototypes
/*******************************************************************************/
int main()
{
	int fd;
	char write_buffer[COUNT];
	char read_buffer[COUNT];
	int count = 0;
	int i;
	
	//init buffers
	memset (read_buffer,0,COUNT);
	for(i=0;i<COUNT;i++)
	{
		write_buffer[i]=i;
	}
		
	/* open special device file  */
	//fd=open("/dev/iot_device", O_RDWR);
	fd=open("./iot_device", O_RDWR);
	
	assert(fd>=0);

	//write to char device
	count = write(fd,write_buffer,COUNT);
	if (count!=COUNT)
	{
	 	printf(" the amount of bytes written is not correct\n");
	} 
	else
	{
		printf(" %d bytes were written to device\n",count);
	}
	
	//read from char device
	count = read(fd,read_buffer,COUNT);
	if (count!=COUNT)
	{
	 	printf(" the amount of bytes read is not correct\n");
	} 
	else
	{
		printf(" %d bytes were read from device\n",count);
	}

	
	close(fd);
	return 0;

}
/*******************************************************************************/
