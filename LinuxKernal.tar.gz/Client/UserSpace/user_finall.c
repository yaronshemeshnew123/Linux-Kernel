#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <unistd.h> 


int8_t write_buf[1024];
int8_t read_buf[1024];


int main()
{
	int fd;
	char option;
	size_t data_size = 0;
	size_t message_size = 0;
	
	printf("welcome to the demo of character device driver...\n");
	fd= open("/dev/iot-device",O_RDWR);
	
	if (fd<0) {
		printf("Cannot open device file...\n");
		return 1;
	}
	
	
	while (1) {

		printf ("*******please enter your option*****\n");
	    printf ("              1.Write               \n");
	
	    printf ("              2.Exit                \n");
	    scanf ("%c", &option);
	    printf ("your options= %c\n", option);
	    
	    
	    switch (option) {
			case '1':
				printf ("Enter the string to write into the driver\n");
				scanf ("%s",write_buf);
				printf ("Data is %s", write_buf);
				
				// calculate message length
				data_size = strlen(write_buf);
				write (fd,write_buf,data_size+1); //write only data to kernel module
				printf("DONE...\n");
				break;
	
			case '2':
				close(fd);
				exit(1);
				break;
			default:
				printf("Enter valid option= %c\n", option);
				break;
		}
		
	}
	
	close (fd);
}
				
