import serial
import struct
from tinydb import TinyDB, Query

class Message(object):
	def __init__(self, dst, src, gas, valves, pipe_temp, cmd_len, user_data, crc):
		self.dst = dst
		self.src = src
		self.gas = gas
		self.valves = valves
		self.pipe_temp = pipe_temp
		self.cmd_len = cmd_len
		self.user_data = user_data
		self.crc = crc
	
	def __str__(self):
		s = ''
		for att, val in self.__dict__.iteritems():
			s += '\t %s = %s\n' % (att, val)			
		return s
		
	def get_dict(self):
		return self.__dict__
	
def get_message(s):
	while s.inWaiting() < 14:
		pass
	
	print 'Got new header!'
	header = s.read(14)
	dst, src, gas, valves, pipe_temp, cmd_len  = struct.unpack('<LLHBHB', header)
	print hex(dst), hex(src), gas, valves, pipe_temp, cmd_len
	
	print 'Waiting for user data...'
	data = s.read(cmd_len)
	
	print 'Waiting for CRC...'
	crc = struct.unpack('<H', s.read(2))[0]
	print 'Message done.'
	
	message = Message(dst, src, gas, valves, pipe_temp, cmd_len, data, crc)
	return message

def save_msg(msg):
	db = TinyDB('db.json')
	db.insert(msg.get_dict())

def main():
	s = serial.Serial('/dev/ttyUSB0', 115200)

	# clean all existing data
	_ = s.read(s.inWaiting())
	while True:
		print 'Waiting for a new message...'
		msg = get_message(s)
		print msg
		print 'Storing message...'
		save_msg(msg)
		
main()
