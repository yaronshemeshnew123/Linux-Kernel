from flask import Flask
from flask import render_template
from tinydb import TinyDB, Query

app = Flask(__name__)

@app.route('/')
def hello_world():
	db = TinyDB('db.json')
	messages = db.all()
	return render_template('template.html', messages = messages)
  

app.run()
